<?php namespace App\Controllers;

use CodeIgniter\Controller;
use App\Models\UserModel;

class Home extends BaseController
{
	public function index()
	{
		return view('welcome_message');
	}

	public function test()
	{
		$db = \Config\Database::connect(); // concexion con la basse de datos
        $consulta='SELECT "Nombre"FROM public."Asignaturas"';
		$result = $db->query($consulta);
		var_dump ($result->getResultArray());
	}

	//--------------------------------------------------------------------

}
